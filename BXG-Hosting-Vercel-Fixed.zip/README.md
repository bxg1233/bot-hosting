# BXG Hosting — Vercel Fixed Version

This version uses Vercel's native layout:
- `public/index.html` = dashboard
- `api/bots.js` = serverless API
- `package.json` = minimal Node project
- No Express catch-all route
- No custom Vercel build configuration required

## Deploy
1. Upload/push this folder to GitHub.
2. Import the repository into Vercel.
3. Leave Framework Preset as `Other`.
4. Deploy.
5. Open the deployment URL.

The dashboard should load at `/` and the API at `/api/bots`.

## Important for real 24/7 Discord hosting
Vercel serverless functions are not an always-on Discord bot worker. This project is the hosting dashboard/API starter. The actual Discord bot processes need a persistent worker/VPS or another always-on runtime, with a database for production state.
