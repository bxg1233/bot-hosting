let bots = [
  {
    id: "demo-bot",
    name: "BXG Demo Bot",
    status: "online",
    cpu: 3.2,
    ram: 128,
    uptime: "12d 4h",
    logs: [
      "[15:42:01] Bot connected to Discord",
      "[15:42:03] Loaded 8 slash commands",
      "[15:42:05] Ready as BXG Demo Bot"
    ]
  },
  {
    id: "moderation",
    name: "Moderation Bot",
    status: "offline",
    cpu: 0,
    ram: 0,
    uptime: "0m",
    logs: ["[15:40:12] Bot stopped"]
  }
];

function send(res, status, data) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve) => {
    let body = "";
    req.on("data", chunk => body += chunk);
    req.on("end", () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { resolve({}); }
    });
  });
}

module.exports = async function handler(req, res) {
  const url = new URL(req.url || "/", "http://localhost");
  const id = url.searchParams.get("id");
  const action = url.searchParams.get("action");
  const logsOnly = url.searchParams.get("logs");

  if (req.method === "GET" && !id && !logsOnly) {
    return send(res, 200, { ok: true, bots });
  }

  if (req.method === "GET" && id && logsOnly) {
    const bot = bots.find(b => b.id === id);
    if (!bot) return send(res, 404, { ok: false, error: "Bot not found" });
    return send(res, 200, { ok: true, logs: bot.logs });
  }

  if (req.method === "POST" && !id) {
    const body = await readBody(req);
    const name = String(body.name || "").trim();
    if (!name) return send(res, 400, { ok: false, error: "Bot name is required" });

    const bot = {
      id: "bot-" + Date.now(),
      name,
      status: "offline",
      cpu: 0,
      ram: 0,
      uptime: "0m",
      logs: ["[" + new Date().toLocaleTimeString() + "] Bot created"]
    };
    bots.push(bot);
    return send(res, 201, { ok: true, bot });
  }

  if (req.method === "POST" && id && action) {
    const bot = bots.find(b => b.id === id);
    if (!bot) return send(res, 404, { ok: false, error: "Bot not found" });

    const time = new Date().toLocaleTimeString();

    if (action === "start") {
      bot.status = "online";
      bot.cpu = 2.1;
      bot.ram = 96;
      bot.uptime = "0m";
      bot.logs.push(`[${time}] Bot started`);
    } else if (action === "stop") {
      bot.status = "offline";
      bot.cpu = 0;
      bot.ram = 0;
      bot.uptime = "0m";
      bot.logs.push(`[${time}] Bot stopped`);
    } else if (action === "restart") {
      bot.status = "online";
      bot.cpu = 2.5;
      bot.ram = 102;
      bot.uptime = "0m";
      bot.logs.push(`[${time}] Bot restarted`);
    } else {
      return send(res, 400, { ok: false, error: "Unknown action" });
    }

    return send(res, 200, { ok: true, bot });
  }

  return send(res, 404, { ok: false, error: "Not found" });
};
