# BXG Hosting — Vercel Edition

## Deploy to Vercel

### GitHub method
1. Create a GitHub repository.
2. Upload this project.
3. In Vercel, choose **Add New Project**.
4. Import the GitHub repository.
5. Deploy.

No build command is required.

### CLI method
Install Vercel CLI, log in, then run:

    vercel

## Important production architecture

This project is the Vercel-hosted dashboard/API layer. Vercel is not the place to keep Discord bot processes running continuously.

For real 24/7 bot hosting, the next layer should be an always-on worker service/VPS that:
- receives bot start/stop/restart commands,
- runs each bot as an isolated process,
- stores bot files,
- injects environment variables securely,
- restarts crashed bots,
- reports CPU/RAM/status back to the dashboard.

The current API uses in-memory demo data, so bot state is not persistent between serverless invocations. Connect a database before production use.
