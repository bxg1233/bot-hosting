const express = require("express");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Demo state for the Vercel frontend.
// For production, replace this with a database such as Postgres/Neon/Supabase.
const bots = [
  {
    id: "demo-bot",
    name: "Demo Bot",
    status: "online",
    cpu: 2.4,
    ram: 82,
    logs: [
      "[BXG] Demo Bot started",
      "[Discord] Connected successfully",
      "[BXG] Ready"
    ]
  }
];

app.get("/api/bots", (_req, res) => {
  res.json(bots);
});

app.post("/api/bots", (req, res) => {
  const name = String(req.body.name || "").trim();
  if (!name) return res.status(400).json({ error: "Bot name is required." });

  const id = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || `bot-${Date.now()}`;
  if (bots.some(b => b.id === id)) {
    return res.status(409).json({ error: "A bot with that name already exists." });
  }

  const bot = {
    id,
    name,
    status: "offline",
    cpu: 0,
    ram: 0,
    logs: [`[BXG] ${name} created`]
  };

  bots.push(bot);
  res.status(201).json(bot);
});

app.post("/api/bots/:id/:action", (req, res) => {
  const bot = bots.find(b => b.id === req.params.id);
  if (!bot) return res.status(404).json({ error: "Bot not found." });

  const action = req.params.action;
  if (!["start", "stop", "restart"].includes(action)) {
    return res.status(400).json({ error: "Invalid action." });
  }

  if (action === "stop") {
    bot.status = "offline";
    bot.cpu = 0;
    bot.ram = 0;
    bot.logs.push("[BXG] Bot stopped");
  } else {
    bot.status = "online";
    bot.cpu = Number((Math.random() * 4 + 0.5).toFixed(1));
    bot.ram = Math.floor(Math.random() * 45 + 55);
    bot.logs.push(`[BXG] Bot ${action === "restart" ? "restarted" : "started"}`);
  }

  res.json(bot);
});

app.get("/api/bots/:id/logs", (req, res) => {
  const bot = bots.find(b => b.id === req.params.id);
  if (!bot) return res.status(404).json({ error: "Bot not found." });
  res.json({ logs: bot.logs });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

module.exports = app;
